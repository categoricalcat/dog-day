import{default as t}from"../components/layout.svelte-4dc315fd.js";export{t as component};
