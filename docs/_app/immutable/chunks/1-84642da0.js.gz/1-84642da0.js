import{default as t}from"../components/error.svelte-46fd018c.js";export{t as component};
