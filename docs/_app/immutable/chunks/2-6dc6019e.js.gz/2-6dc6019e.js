import{default as t}from"../components/pages/_page.svelte-9a619e0a.js";const e=!0;export{t as component,e as server};
